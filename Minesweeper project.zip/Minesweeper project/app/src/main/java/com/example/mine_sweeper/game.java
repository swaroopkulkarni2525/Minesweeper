package com.example.mine_sweeper;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class game extends AppCompatActivity {
    int percent =15;
    int currentscore=0;
    private Vibrator myvibe;
    Button easy;
    Button medium;
    Button hard;
    TextView g01;
    TextView g02;
    TextView res;
    Button R0c0;
    Button R0c1;
    Button R0c2;
    Button R0c3;
    Button R0c4;
    Button R0c5;
    Button R0c6;
    Button R1c0;
    Button R1c1;
    Button R1c2;
    Button R1c3;
    Button R1c4;
    Button R1c5;
    Button R1c6;
    Button R2c0;
    Button R2c1;
    Button R2c2;
    Button R2c3;
    Button R2c4;
    Button R2c5;
    Button R2c6;
    Button R3c0;
    Button R3c1;
    Button R3c2;
    Button R3c3;
    Button R3c4;
    Button R3c5;
    Button R3c6;
    Button R4c0;
    Button R4c1;
    Button R4c2;
    Button R4c3;
    Button R4c4;
    Button R4c5;
    Button R4c6;
    Button R5c0;
    Button R5c1;
    Button R5c2;
    Button R5c3;
    Button R5c4;
    Button R5c5;
    Button R5c6;
    Button R6c0;
    Button R6c1;
    Button R6c2;
    Button R6c3;
    Button R6c4;
    Button R6c5;
    Button R6c6;
    final int[][] board=new int[7][7];
    int numMines=0;
    public void g0(boolean state){
        state=false;

    }
        public void CheckIfOver() {
           //




    }
    void setup(){
        R0c0=findViewById(R.id.r0c0);
        R0c1=findViewById(R.id.r0c1);
        R0c2=findViewById(R.id.r0c2);
        R0c3=findViewById(R.id.r0c3);
        R0c4=findViewById(R.id.r0c4);
        R0c5=findViewById(R.id.r0c5);
        R0c6=findViewById(R.id.r0c6);
        R1c0=findViewById(R.id.r1c0);
        R1c1=findViewById(R.id.r1c1);
        R1c2=findViewById(R.id.r1c2);
        R1c3=findViewById(R.id.r1c3);
        R1c4=findViewById(R.id.r1c4);
        R1c5=findViewById(R.id.r1c5);
        R1c6=findViewById(R.id.r1c6);
        R2c0=findViewById(R.id.r2c0);
        R2c1=findViewById(R.id.r2c1);
        R2c2=findViewById(R.id.r2c2);
        R2c3=findViewById(R.id.r2c3);
        R2c4=findViewById(R.id.r2c4);
        R2c5=findViewById(R.id.r2c5);
        R2c6=findViewById(R.id.r2c6);
        R3c0=findViewById(R.id.r3c0);
        R3c1=findViewById(R.id.r3c1);
        R3c2=findViewById(R.id.r3c2);
        R3c3=findViewById(R.id.r3c3);
        R3c4=findViewById(R.id.r3c4);
        R3c5=findViewById(R.id.r3c5);
        R3c6=findViewById(R.id.r3c6);
        R4c0=findViewById(R.id.r4c0);
        R4c1=findViewById(R.id.r4c1);
        R4c2=findViewById(R.id.r4c2);
        R4c3=findViewById(R.id.r4c3);
        R4c4=findViewById(R.id.r4c4);
        R4c5=findViewById(R.id.r4c5);
        R4c6=findViewById(R.id.r4c6);
        R5c0=findViewById(R.id.r5c0);
        R5c1=findViewById(R.id.r5c1);
        R5c2=findViewById(R.id.r5c2);
        R5c3=findViewById(R.id.r5c3);
        R5c4=findViewById(R.id.r5c4);
        R5c5=findViewById(R.id.r5c5);
        R5c6=findViewById(R.id.r5c6);
        R6c0=findViewById(R.id.r6c0);
        R6c1=findViewById(R.id.r6c1);
        R6c2=findViewById(R.id.r6c2);
        R6c3=findViewById(R.id.r6c3);
        R6c4=findViewById(R.id.r6c4);
        R6c5=findViewById(R.id.r6c5);
        R6c6=findViewById(R.id.r6c6);
        easy=findViewById(R.id.Easy);
        medium=findViewById(R.id.Medium);
        hard=findViewById(R.id.Hard);
        res=findViewById(R.id.view_result);

    }

        void CreateBoard() {
            for (int i = 0; i < 7; i++) {
                for (int j = 0; j < 7; j++) {
                    if (Math.random() * 100 < percent) {
                        board[i][j] = -1;
                        numMines++;
                        if (i > 0 && j > 0) { // top left
                            if (board[i - 1][j - 1] >= 0) {
                                board[i - 1][j - 1]++;
                            }
                        }
                        if (j > 0) { // top
                            if (board[i][j - 1] >= 0) {
                                board[i][j - 1]++;
                            }
                        }
                        if (i < 6 && j > 0) { // top right
                            if (board[i + 1][j - 1] >= 0) {
                                board[i + 1][j - 1]++;
                            }
                        }
                        if (i > 0) { // left
                            if (board[i - 1][j] >= 0) {
                                board[i - 1][j]++;
                            }
                        }
                        if (i < 6) { // right
                            if (board[i + 1][j] >= 0) {
                                board[i + 1][j]++;
                            }
                        }
                        if (i > 0 && j < 6) { // bottom left
                            if (board[i - 1][j + 1] >= 0) {
                                board[i - 1][j + 1]++;
                            }
                        }
                        if (j < 6) { // bottom
                            if (board[i][j + 1] >= 0) {
                                board[i][j + 1]++;
                            }
                        }
                        if (i < 6 && j < 6) { // bottom right
                            if (board[i + 1][j + 1] >= 0) {
                                board[i + 1][j + 1]++;
                            }
                        }
                    }
                    Log.e("Ms:create board", "spot created");
                }
            }
        }


    void disableGrid(){
     R0c0.setEnabled(false);
     R0c1.setEnabled(false);
     R0c2.setEnabled(false);
     R0c3.setEnabled(false);
     R0c4.setEnabled(false);
     R0c5.setEnabled(false);
     R0c6.setEnabled(false);
     R1c0.setEnabled(false);
        R1c1.setEnabled(false);
        R1c2.setEnabled(false);
        R1c3.setEnabled(false);
        R1c4.setEnabled(false);
        R1c5.setEnabled(false);
        R1c6.setEnabled(false);
        R2c0.setEnabled(false);
        R2c1.setEnabled(false);
        R2c2.setEnabled(false);
        R2c3.setEnabled(false);
        R2c4.setEnabled(false);
        R2c5.setEnabled(false);
        R2c6.setEnabled(false);
        R3c0.setEnabled(false);
        R3c1.setEnabled(false);
        R3c2.setEnabled(false);
        R3c3.setEnabled(false);
        R3c4.setEnabled(false);
        R3c5.setEnabled(false);
        R3c6.setEnabled(false);
        R4c0.setEnabled(false);
        R4c1.setEnabled(false);
        R4c2.setEnabled(false);
        R4c3.setEnabled(false);
        R4c4.setEnabled(false);
        R4c5.setEnabled(false);
        R4c6.setEnabled(false);
        R5c0.setEnabled(false);
        R5c1.setEnabled(false);
        R5c2.setEnabled(false);
        R5c3.setEnabled(false);
        R5c4.setEnabled(false);
        R5c5.setEnabled(false);
        R5c6.setEnabled(false);
        R6c0.setEnabled(false);
        R6c1.setEnabled(false);
        R6c2.setEnabled(false);
        R6c3.setEnabled(false);
        R6c4.setEnabled(false);
        R6c5.setEnabled(false);
        R6c6.setEnabled(false);
    }
    void enableGrid(){
        R0c0.setEnabled(true);
        R0c1.setEnabled(true);
        R0c2.setEnabled(true);
        R0c3.setEnabled(true);
        R0c4.setEnabled(true);
        R0c5.setEnabled(true);
        R0c6.setEnabled(true);
        R1c0.setEnabled(true);
        R1c1.setEnabled(true);
        R1c2.setEnabled(true);
        R1c3.setEnabled(true);
        R1c4.setEnabled(true);
        R1c5.setEnabled(true);
        R1c6.setEnabled(true);
        R2c0.setEnabled(true);
        R2c1.setEnabled(true);
        R2c2.setEnabled(true);
        R2c3.setEnabled(true);
        R2c4.setEnabled(true);
        R2c5.setEnabled(true);
        R2c6.setEnabled(true);
        R3c0.setEnabled(true);
        R3c1.setEnabled(true);
        R3c2.setEnabled(true);
        R3c3.setEnabled(true);
        R3c4.setEnabled(true);
        R3c5.setEnabled(true);
        R3c6.setEnabled(true);
        R4c0.setEnabled(true);
        R4c1.setEnabled(true);
        R4c2.setEnabled(true);
        R4c3.setEnabled(true);
        R4c4.setEnabled(true);
        R4c5.setEnabled(true);
        R4c6.setEnabled(true);
        R5c0.setEnabled(true);
        R5c1.setEnabled(true);
        R5c2.setEnabled(true);
        R5c3.setEnabled(true);
        R5c4.setEnabled(true);
        R5c5.setEnabled(true);
        R5c6.setEnabled(true);
        R6c0.setEnabled(true);
        R6c1.setEnabled(true);
        R6c2.setEnabled(true);
        R6c3.setEnabled(true);
        R6c4.setEnabled(true);
        R6c5.setEnabled(true);
        R6c6.setEnabled(true);

    }
    void disableMenu(){
        easy.setEnabled(false);
        medium.setEnabled(false);
        hard.setEnabled(false);

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        setup();
        disableGrid();
        easy.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        disableMenu();
                                        percent = 25;
                                        CreateBoard();
                                        enableGrid();
                                    }
                                });

        medium.setOnClickListener(new View.OnClickListener() {
                                      @Override
                                      public void onClick(View view) {
                                          disableMenu();
                                          percent=30;
                                          CreateBoard();
                                          enableGrid();
                                      }
                                  });

        hard.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        disableMenu();
                                        percent=35;
                                        CreateBoard();
                                        enableGrid();
                                    }
                                });

        R0c0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R0c0.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R0c0.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R0c0.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R0c1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R0c1.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R0c1.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R0c1.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R0c2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R0c2.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R0c2.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R0c2.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R0c3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R0c3.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R0c3.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R0c3.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R0c4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R0c4.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R0c4.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R0c4.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R0c5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R0c5.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R0c5.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R0c5.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R0c6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R0c6.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R0c6.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R0c6.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R1c0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R1c0.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R1c0.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R1c0.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R1c1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R1c1.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R1c1.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R1c1.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R1c2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R1c2.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R1c2.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R1c2.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R1c3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R1c3.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R1c3.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R1c3.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R1c4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R1c4.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R1c4.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R1c4.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R1c5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R1c5.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R1c5.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R1c5.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R1c6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R1c6.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R1c6.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R1c6.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R2c0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R2c0.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R2c0.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R2c0.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R2c1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R2c1.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R2c1.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R2c1.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R2c2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R2c2.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R2c2.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R2c2.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R2c3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R2c3.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R2c3.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R2c3.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R2c4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R2c4.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R2c4.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R2c4.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R2c5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R2c5.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R2c5.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R2c5.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R2c6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R2c6.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R2c6.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R2c6.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R3c0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R3c0.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R3c0.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R3c0.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R3c1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R3c1.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R3c1.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R3c1.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R3c2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R3c2.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R3c2.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R3c2.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R3c3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R3c3.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R3c3.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R3c3.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R3c4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R3c4.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R3c4.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R3c4.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R3c5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R3c5.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R3c5.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R3c5.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R3c6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R3c6.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R3c6.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R3c6.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R4c0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R4c0.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R4c0.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R4c0.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R4c1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R4c1.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R4c1.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R4c1.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R4c2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R4c2.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R4c2.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R4c2.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R4c3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R4c3.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R4c3.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R4c3.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R4c4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R4c4.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R4c4.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R4c4.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R4c5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R4c5.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R4c5.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R4c5.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R4c6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R4c4.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R4c6.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R4c6.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R5c0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R5c0.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R5c0.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R5c0.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R5c1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R5c1.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R5c1.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R5c1.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R5c2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R5c2.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R5c2.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R5c2.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R5c3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R5c3.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R5c3.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R5c3.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R5c4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R5c4.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R5c4.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R5c4.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R5c5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R5c5.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R5c5.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R5c5.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R5c6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R5c6.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R5c6.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R5c6.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R6c0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R6c0.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R6c0.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R6c0.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R6c1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R6c1.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R6c1.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R6c1.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R6c2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R6c2.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R6c2.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R6c2.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R6c3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R6c3.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R6c3.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R6c3.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R6c4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R6c4.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R6c4.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R6c4.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R6c5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R6c5.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R6c5.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R6c5.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });
        R6c6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                R6c6.setEnabled(false);
                res.setText(String.valueOf(currentscore));
                if (board[0][0] > 0) {
                    R6c6.setText(String.valueOf(board[0][0]));
                    currentscore++;
                }
                else if(board[0][0]<0){
                    Log.d("","mine clicked");
                    R6c6.setText("x");
                    g0(true);
                }
                CheckIfOver();
            }
        });

    }
}